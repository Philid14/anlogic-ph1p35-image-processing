import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('C:/Users/Kelinna/Documents/Codex/2026-10-16/AnlogicTrack2/work/target-text-atomic')
OUT=Path(__file__).resolve().parent/'checks-02'
OUT.mkdir(exist_ok=False)
tool=ROOT/'features/color_target/tools/check_target_config.py'
template=ROOT/'features/color_target/integration/TARGET_CONFIG_PENDING.json'
base=json.loads(template.read_text())
valid=dict(base,max_target_age_ticks=1000003,max_reliable_age_ticks=2000003,
    tick_hz=100000000,max_capture_to_display_start_ticks=100,max_scan_ticks=200)
cases=[('pending',base,'configuration',2),('fixture_declared',valid,'configuration',0),
       ('fixture_integration_unverified',valid,'integration',2),
       ('zero_age',dict(valid,max_target_age_ticks=0),'configuration',1),
       ('boolean_age',dict(valid,max_target_age_ticks=True),'configuration',1),
       ('filter_enabled',dict(valid,filter_enable=True),'configuration',1),
       ('duplicate_key','{"schema":1,"schema":1}','configuration',1)]
rows=[]
for name,config,gate,wanted in cases:
    path=OUT/(name+'.fixture.json')
    path.write_text(config if type(config) is str else json.dumps(config,indent=2)+'\n')
    command=[sys.executable,'-B','-X','utf8',str(tool),'--config',str(path),
             '--gate',gate,'--out',str(OUT/name)]
    p=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (OUT/(name+'.log')).write_bytes(p.stdout)
    row=dict(name=name,command=command,expected_exit=wanted,actual_exit=p.returncode,
        matched=p.returncode==wanted,summary=json.loads((OUT/name/'summary.json').read_text()))
    rows.append(row);print(name,p.returncode,'expected',wanted)
command=[sys.executable,'-B','-X','utf8',str(ROOT/'features/color_target/tb/test_guard_engineering.py')]
p=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'engineering-tests.log').write_bytes(p.stdout)
report=dict(scope='Tool/configuration tests and declared fixtures; NOT real integration settings',
    cases=rows,unit_command=command,unit_exit=p.returncode,
    code_sha256={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in
        [tool,ROOT/'features/color_target/tb/test_guard_engineering.py',ROOT/'features/color_target/run_guard_synthesis.py']},
    matched=all(r['matched'] for r in rows) and p.returncode==0)
(OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print('CHECK_SUITE_COMPLETE matched=',report['matched'])
raise SystemExit(0 if report['matched'] else 1)
