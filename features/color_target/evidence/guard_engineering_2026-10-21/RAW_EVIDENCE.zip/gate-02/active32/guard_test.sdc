create_clock -name guard_test_clk -period 10.0 [get_ports clk]
