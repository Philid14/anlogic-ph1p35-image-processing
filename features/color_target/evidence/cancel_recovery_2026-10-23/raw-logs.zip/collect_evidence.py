"""Assemble this phase's evidence; no production writes or hardware actions."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

OUT=Path(__file__).resolve().parent
REPO=OUT.parents[1]/'work/target-text-atomic'
SRC=OUT.parent/'latest-readiness-2026-10-23/candidate-source'
MANIFEST=SRC.parent/'snapshot-manifest.json'
FEATURE=REPO/'features/color_target'
fixture=OUT/'synthetic-replay-input';fixture.mkdir(exist_ok=False)
(fixture/'blank.ppm').write_bytes(b'P6\n1280 720\n255\n'+bytes(1280*720*3))
data=dict(schema=1,clips=[dict(clip_id='synthetic-profile-check',group_id='synthetic-only',split='validation',
    source_kind='synthetic',pixel_tap='post_awb_pre_style_rgb888',width=1280,height=720,
    frames=[dict(path='blank.ppm',session=1,frame=0,annotation=None)])])
(fixture/'manifest.json').write_text(json.dumps(data,indent=2)+'\n')
jobs=[('replay-profile-cli',0,[sys.executable,'-B','-X','utf8',str(FEATURE/'tools/prepare_candidate_replay.py'),
    '--manifest',str(fixture/'manifest.json'),'--source',str(SRC),'--snapshot-manifest',str(MANIFEST),'--out',str(OUT/'candidate-profile')]),
    ('board-template-cli',0,[sys.executable,'-B','-X','utf8',str(FEATURE/'tools/check_board_run.py'),'--template',str(OUT/'board-run-blank.json')]),
    ('board-blank-cli',2,[sys.executable,'-B','-X','utf8',str(FEATURE/'tools/check_board_run.py'),str(OUT/'board-run-blank.json'),
        '--bit',str(SRC/'artifacts/bitstreams/STYLE_V2_TARGET_V1/camera_to_dsi_display.bit'),'--out',str(OUT/'board-blank-analysis.json')])]
results=[]
for label,expected,argv in jobs:
    p=subprocess.run(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
    (OUT/(label+'.txt')).write_bytes(p.stdout)
    results.append(dict(label=label,argv=argv,exit_code=p.returncode,expected_exit_code=expected,matched=p.returncode==expected))
    if p.returncode!=expected:raise RuntimeError(label)
snapshot=json.loads(MANIFEST.read_text())
unchanged=all(hashlib.sha256((SRC/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in snapshot['files'])
assert unchanged
summary=dict(assessment='REVIEW_REQUIRED',production_snapshot_unchanged=unchanged,snapshot_files=len(snapshot['files']),
    main_revision=snapshot['commit'],latency_revision='87bb9a5375843c4f3e9696eb0dbd028f3e364f47',
    warm_trace=json.loads((OUT/'warm-01/summary.json').read_text()),
    latency_review=json.loads((OUT/'latency-v2-02/summary.json').read_text()),
    software_selftests=dict(board=18,replay_input=3),cli_jobs=results,
    actual_camera_material_used=False,new_synthesis_route_bit=False,board_test=False,
    boundary='No MAIN/LATENCY/production TARGET changes; no integrated guard temporal replay or final HDMI pixels in this fault case')
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=['board-tool-tests.txt','board-tool-tests-final.txt','replay-preflight-tests.txt',
       'replay-profile-cli.txt','board-template-cli.txt','board-blank-cli.txt','board-run-blank.json',
       'board-blank-analysis.json','candidate-profile/profile.json','synthetic-replay-input/manifest.json','summary.json','collect_evidence.py']
for folder in ('warm-01','latency-v2-01','latency-v2-02'):
    names += [str(p.relative_to(OUT)).replace('\\','/') for p in (OUT/folder).iterdir()
              if p.is_file() and p.name in ('stage_0.txt','stage_1.txt','stage_2.txt','stages.json','summary.json',
                  'SOURCE_MANIFEST.json','events.txt','tb_cancel_recovery.sv','frame_event_bridge.v','latency_meter.v','tb_latency_review_v2.sv')]
# Keep the incompatible old test evidence separate from genuine V2 failures.
old=OUT/'latency-87bb9a5-01'
names += ['latency-87bb9a5-01/summary.json']
names += [str(p.relative_to(OUT)).replace('\\','/') for p in old.glob('*/*.log')]
index={name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in sorted(set(names))}
(OUT/'RAW_INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
dest=FEATURE/'evidence/cancel_recovery_2026-10-23';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw-logs.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for name in index:z.write(OUT/name,name)
    z.write(OUT/'RAW_INDEX.json','RAW_INDEX.json')
for name in ('summary.json','RAW_INDEX.json'):(dest/name).write_bytes((OUT/name).read_bytes())
print(json.dumps(dict(source_unchanged=unchanged,archive_files=len(index)+1,archive_bytes=(dest/'raw-logs.zip').stat().st_size,
    cli_expected_exits_matched=all(r['matched'] for r in results),archive=str(dest)),indent=2))
