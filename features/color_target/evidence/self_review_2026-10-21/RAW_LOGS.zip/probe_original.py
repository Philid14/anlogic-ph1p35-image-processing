"""Preserve counterexamples against 131b438's evidence parser and stimulus."""
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path('C:/Users/Kelinna/Documents/Codex/2026-10-16/AnlogicTrack2/work/target-text-atomic')
OUT=Path(__file__).resolve().parent
OLD=ROOT.parents[1]/'outputs/latency-handoff-review-2026-10-20/rtl-03'
sys.path.insert(0,str(ROOT/'features/color_target'))
old_source=subprocess.check_output(['git','show','131b438:features/color_target/run_latency_handoff_review.py'],cwd=ROOT)
namespace=dict(__name__='original_review_131b438',__file__=str(ROOT/'features/color_target/run_latency_handoff_review.py'))
exec(compile(old_source,'131b438/run_latency_handoff_review.py','exec'),namespace)
parse_case=namespace['parse_case']
text=(OLD/'normal_and_repeat/vsim.log').read_text(encoding='utf-8')
probes={
 'changed_gold_to_match_wrong_value':text.replace('name=normal_stats_valid expected=1 actual=1 pass=1','name=normal_stats_valid expected=0 actual=0 pass=1'),
 'nonbinary_pass_flag':text.replace('name=normal_stats_valid expected=1 actual=1 pass=1','name=normal_stats_valid expected=1 actual=1 pass=2'),
 'changed_requirement_into_setup':text.replace('setup=0 name=normal_stats_valid','setup=1 name=normal_stats_valid'),
}
results=[]
for name,bad in probes.items():
    assert bad!=text
    row=parse_case(bad,0,True)
    results.append(dict(name=name,incorrect_evidence_accepted=row['evidence_valid'],incorrect_pass=row['requirements_satisfied']))
    (OUT/(name+'.log')).write_text(bad,encoding='utf-8')
dump=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
dump(OUT/'before-parser-probes.json',results)
# Ask the previously compiled original bench to emit only its public input.
vcd=(OUT/'original-full-input.vcd').as_posix()
command=['D:/altera/14.1/modelsim_ase/win32aloem/vsim.exe','-c','-onfinish','stop',
 'work.tb_latency_handoff_review','-GCASE_ID=2','-do',
 f'vcd file {vcd}; vcd add /tb_latency_handoff_review/be; run -all; quit -f -code 0']
p=subprocess.run(command,cwd=OLD/'bridge_full_loss',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
(OUT/'original-vcd-tool.log').write_bytes(p.stdout)
assert p.returncode==0 and Path(vcd).is_file()
raw=Path(vcd).read_text();marker=None;times=[];now=0
for line in raw.splitlines():
    if line.startswith('$var') and line.split()[4]=='be':marker=line.split()[3]
    if line.startswith('#'):now=int(line[1:])
    if marker is not None and line=='1'+marker:times.append(now)
assert len(times)==20
gaps=[b-a for a,b in zip(times,times[1:])]
dump(OUT/'original-stimulus-gaps.json',dict(vcd_timescale_header=raw[:raw.index('$enddefinitions')],
    rise_times=times,gaps=gaps,documented_source_period_ns=10,
    documented_gap_cycles=5,observed_gap_vcd_units=sorted(set(gaps))))
print(json.dumps(results));print('Original VCD gaps:',sorted(set(gaps)))
