import json
from pathlib import Path
import subprocess
import sys

ROOT=Path('C:/Users/Kelinna/Documents/Codex/2026-10-16/AnlogicTrack2/work/target-text-atomic')
OUT=Path(__file__).resolve().parent
RUN=OUT/'rtl-01'
sys.path.insert(0,str(ROOT/'features/color_target'))
from run_latency_handoff_review import gate_results, parse_case
rows=[]
for path in sorted(OUT.glob('*.log')):
    if path.stem in ('changed_gold_to_match_wrong_value','nonbinary_pass_flag','changed_requirement_into_setup'):
        result=parse_case(path.read_text(encoding='utf-8'),0,True)
        assert not result['evidence_valid']
        rows.append(dict(name=path.stem,evidence_rejected=True))
assert len(rows)==3
vcd=(OUT/'corrected-full-input.vcd').as_posix()
command=['D:/altera/14.1/modelsim_ase/win32aloem/vsim.exe','-c','-onfinish','stop',
 'work.tb_latency_handoff_review','-GCASE_ID=2','-do',
 f'vcd file {vcd}; vcd add /tb_latency_handoff_review/be; run -all; quit -f -code 0']
p=subprocess.run(command,cwd=RUN/'bridge_full_loss',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
(OUT/'corrected-vcd-tool.log').write_bytes(p.stdout)
assert p.returncode==0
raw=Path(vcd).read_text();marker=None;times=[];now=0
for line in raw.splitlines():
    if line.startswith('$var') and line.split()[4]=='be':marker=line.split()[3]
    if line.startswith('#'):now=int(line[1:])
    if marker is not None and line=='1'+marker:times.append(now)
gaps=[b-a for a,b in zip(times,times[1:])]
assert len(times)==20 and set(gaps)=={50000}
summary=json.loads((RUN/'summary.json').read_text(encoding='utf-8'))
assert summary['evidence_valid'] and len(summary['jobs'])==9
report=dict(parser_rejection_probes=rows,corrected_rise_times=times,corrected_gaps_ps=gaps,
    gates={key:gate_results(summary['jobs'],True,key) for key in ('component','integration')})
(OUT/'after-probes.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Prior corrupted evidence rejected: 3/3; measured new gap: 5 source cycles')
