from pathlib import Path
import subprocess,json,hashlib,time
root=Path('D:/anlogic_formal_project');hdl=root/'in_out_example/lab_ex3_osd_SC500_720P/lab_ex3_osd/user_source/hdl_source';out=root/'tmp/color_compare_v1/full/native03';out.mkdir(exist_ok=False)
paths=['isp/edge_control_stream.v','isp/rgb_effects_96.v','isp/style_fill_96.v','isp/edge_detect_96.v','isp/gaussian_pair_3x3.v','isp/nms_gradient_pair_3x3.v','isp/edge_link_pair_3x3.v','isp/edge_center_pair_delay.v','isp/edge_temporal_hold.v','isp/color_compare_stats.v','isp/color_compare_osd.v','edge_status_osd.v','osd_char_lib.v','data_96bit_to_128bit.v','isp/isp_top.v','isp/data128_96/data128_96.v']
sources=[root/'tests/tb_edge_style_stream.v']+[hdl/x for x in paths]+[root/'tests/isp_boundary_stubs.v']
original=hdl/'isp/edge_detect_96.v'
text=original.read_text();decl="        wire [13:0] low_threshold={1'b0,nms_threshold[13:1]};\n"
assert text.count(decl)==1
adjusted=text.replace(decl,'').replace('        reg [3:0] classified;',decl+'        reg [3:0] classified;')
assert adjusted.replace(decl,'')==text.replace(decl,'')
copy=out/'edge_detect_declaration_order.v';copy.write_text(adjusted)
(out/'DIALECT_ADAPTATION.json').write_text(json.dumps(dict(reason='ModelSim rejects a forward net declaration in an existing generate block; TD and Icarus accept original',original_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),copy_sha256=hashlib.sha256(copy.read_bytes()).hexdigest(),only_change='move identical low_threshold wire declaration before first procedural reference',non_declaration_text_identical=True),indent=2)+'\n')
sources=[copy if x==original else x for x in sources]
(out/'SOURCE_MANIFEST.json').write_text(json.dumps({p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2)+'\n')
exe=Path('D:/modelsim/modelsim_ase/win32aloem');stages=[]
commands=[[str(exe/'vlib.exe'),'work'],[str(exe/'vlog.exe'),'-sv','-work','work']+[str(p) for p in sources],[str(exe/'vsim.exe'),'-c','-onfinish','exit','work.tb_edge_style_stream','-gWIDTH=1280','-gHEIGHT=720','-gCOMPARE=1','+STIM='+str(out.parent/'stim.txt'),'+PACK='+str(out.parent/'pack.txt'),'+WORDS=864000','-do','onerror {quit -code 1}; run -all; quit -code 0']]
for i,cmd in enumerate(commands):
 started=time.time()
 with (out/f'stage_{i}.txt').open('wb') as log:r=subprocess.run(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT)
 stages.append(dict(index=i,exit_code=r.returncode,wall_seconds=time.time()-started));(out/'stages.json').write_text(json.dumps(stages,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
print('native full simulation finished')
