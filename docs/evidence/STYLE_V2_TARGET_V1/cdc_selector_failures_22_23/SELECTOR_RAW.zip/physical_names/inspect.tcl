source {D:/anlogic_formal_project/in_out_example/lab_ex3_osd_SC500_720P/lab_ex3_osd/td_project/camera_to_dsi_display_Runs/phy_1/settings.cfg}
import_device ph1_35p.db -package PH1P35MDG324 -speed 3
open_project camera_to_dsi_display.prj -noanalyze
import_db {D:/anlogic_formal_project/tmp/style_v2_target_v1/route_explicit_logo_20/route.db}
puts "GRAY_CELLS [get_cells *u_reader*primary_addr_gray*]"
puts "SYNC_CELLS [get_cells *u_reader*sync_r1*]"
puts "GRAY_NETS [get_nets *u_reader*primary_addr_gray*]"
puts "SYNC_PINS [get_pins *u_reader*sync_r1*]"
puts "INSPECT_COMPLETE"
exit
